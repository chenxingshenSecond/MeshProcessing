function Img_undistort = Undistort_Images(img,MultiCamParam,camNum)



R=eye(3);
fc=MultiCamParam{camNum+1}.fc;
cc=MultiCamParam{camNum+1}.cc;
kc=MultiCamParam{camNum+1}.kc;
alpha_c=MultiCamParam{camNum+1}.alpha_c;
fisheye=MultiCamParam{camNum+1}.fisheye;
KK=MultiCamParam{camNum+1}.IntrinsicMatrix;

if size(img,3)>1
    
    a=rect(double(img(:,:,1)),R,fc,cc,kc,alpha_c,KK,fisheye);
    b=rect(double(img(:,:,2)),R,fc,cc,kc,alpha_c,KK,fisheye);
    c=rect(double(img(:,:,3)),R,fc,cc,kc,alpha_c,KK,fisheye);
    Img_undistort=uint8(cat(3,a,b,c));
    
else
    Img_undistort=rect(img,R,fc,cc,kc,alpha_c,KK,fisheye);
end