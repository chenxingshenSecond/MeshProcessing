function [ img_data ]=ProjectiveLowCams(im_resize,ScreenParm)  
im_gray=double(rgb2gray(im_resize));
im_gray=im_gray/max(max(im_gray));
im_blue=double(im_resize(:,:,3));
im_blue=im_blue/max(max(im_blue)); %% 
%% cgw
im=im_blue ;% .*im_gray;
%% 

im_bw    =  im2bw ( im , 0.7 * graythresh(im) );
im_close =  imclose( im_bw,strel('disk',25)); 

figure ; %% cgw
imshow( im2bw( im , 0.7*graythresh(im ) )  ) ; %   cgw comments
% figure;imshow(im_bw,[]);
% figure;imshow(im_close,[]);
CC=bwconncomp( im_close, 8 );
numPixels=cellfun(@numel,CC.PixelIdxList);
[a,idx]=sort(numPixels,'descend');
im_biggest=zeros(size(im_bw));
im_biggest(CC.PixelIdxList{idx(1)})=1;
%% 
im_second=zeros(size(im_bw));
im_second(CC.PixelIdxList{idx(2)})=1;

im_biggest_inv=~im_biggest;
CC=bwconncomp(im_biggest_inv, 4);
numPixels=cellfun(@numel,CC.PixelIdxList);
[a,idx]=sort(numPixels,'descend');

im_interior=zeros(size(im_biggest_inv));
im_interior(CC.PixelIdxList{idx(2)})=1;
%% 
im_outer_box   = im_interior+im_biggest;
im_canny_outerbox=edge(im_outer_box,'canny');  
%% cgw
im_canny_outerbox = imdilate( im_canny_outerbox,ones( 5 ));%ͼ������
%% cgw  
% % figure , imshow(im_canny_outerbox) ; %  cgw 

%% 
%% 
[H1,T1,R1] = hough( im_canny_outerbox ,'Theta',-90:0.1:90-0.1);
%��ֵ��
Peaks=houghpeaks( H1 , 10 );
%%

%�õ��߶���Ϣ
lines              = houghlines( im_canny_outerbox ,T1,R1,Peaks);
lines4_outerbox    = FindBoxEdges(lines); %  

%% cgw ������ͱȽ��Ѱ� %%  �����ڴ˴����ñ�ĺ��� %% 
if length(lines4_outerbox)~=4 
    img_data = 0 ; 
    disp(['1  canny_outerbox  length(lines4_outerbox) = ', num2str(length(lines4_outerbox)) ,'  and not found' ]) ;  
else
    corners_outerbox=FindCorners(lines4_outerbox);
   % return ; 
    %error('4 lines');
end 
% hold on ;
% max_len = 0;
% for k = 1:length(lines)
%    xy = [lines(k).point1; lines(k).point2];
%    plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');
% 
%    % Plot beginnings and ends of lines
%    plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
%    plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');
% 
%    % Determine the endpoints of the longest line segment
%    len = norm(lines(k).point1 - lines(k).point2);
%    if ( len > max_len)
%       max_len = len;
%       xy_long = xy;
%    end
% end



im_canny_innerbox = edge(im_interior,'canny'); 
im_canny_innerbox = imdilate( im_canny_innerbox,ones( 5 ) );%ͼ������

%% 
%% 
[H1,T1,R1] = hough( im_canny_innerbox ,'Theta',-90:0.1:90-0.1);
%��ֵ��
Peaks=houghpeaks( H1 , 10 );
%%

%�õ��߶���Ϣ
lines              = houghlines( im_canny_innerbox ,T1,R1,Peaks); 
lines4_innerbox    = FindBoxEdges(lines);
%% cgw ������ͱȽ��Ѱ� %%  �����ڴ˴����ñ�ĺ��� %% 
if length(lines4_innerbox)~=4 
        img_data = 0 ; 
    disp(['2 canny_innerbox  length(lines4_innerbox) = ', num2str(length(lines4_innerbox)) ,'  and not found' ]) ;  
else
    corners_innerbox=FindCorners(lines4_innerbox);
    % return ; 
   % error('4 lines');
end 


%% cgw
hold on ;
max_len = 0;
for k = 1:length(lines4_innerbox)
   xy = [lines4_innerbox(k).point1; lines4_innerbox(k).point2];
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');

   % Plot beginnings and ends of lines
   plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

   % Determine the endpoints of the longest line segment
   len = norm(lines4_innerbox(k).point1 - lines4_innerbox(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end

im_canny_square = edge(im_interior,'canny'); 
im_canny_square = imdilate( im_canny_square ,ones(5));%ͼ������

%% 
%% 
[H1,T1,R1] = hough( im_canny_square ,'Theta',-90:0.1:90-0.1);
%��ֵ��
Peaks = houghpeaks( H1 , 10 );
%%
%�õ��߶���Ϣ
lines              = houghlines( im_canny_square ,T1,R1,Peaks); 

lines4_square=FindBoxEdges(lines);

if length(lines4_square)~=4 
        img_data = 0 ; 
    disp([' 3 canny_square length(lines4_square) = ', num2str(length(lines4_square)) ,'  and not found' ]) ;  
else
    corners_square=FindCorners(lines4_square);
  %  return ;  
end


width=ScreenParm.width*10;
height=ScreenParm.height*10;
PLength=width/2048;


cornerT_outerbox=[  0 , width ,  width  , 0   ;
                    0 , 0     ,  height , height];
              
% 
% cornerT_innerbox=[20*PLength   ,   width-20*PLength    , width-20*PLength   , 20  *     PLength    ;
%                   20*PLength   ,   20  *    PLength    , height-20*PLength  , height - 20 * PLength];
%               
% cornerT_square=[width/2-200*PLength  , width/2+200*PLength  , width/2+200*PLength  , width/2-200*PLength;
%                 height/2-200*PLength , height/2-200*PLength , height/2+200*PLength , height/2+200*PLength];         
%                 
% CornersT   = [ cornerT_outerbox , cornerT_innerbox , cornerT_square];
% CornersImg = [ corners_outerbox , corners_innerbox , corners_square];
%                
CornersT   = [ cornerT_outerbox ];
CornersImg = [ corners_outerbox ];

% CornersT   = [ cornerT_outerbox ,cornerT_innerbox];
% CornersImg = [ corners_outerbox , corners_innerbox];

 fixed_points   = CornersT'    ;
 moving_points  = CornersImg'  ;
 
 tform        = cp2tform( moving_points , fixed_points , 'projective' );
 tform_pro    = projective2d(tform.tdata.T);
 [img_pro,RB] = imwarp( im_resize  , tform_pro , 'cubic' );


xdata=RB.XWorldLimits;
ydata=RB.YWorldLimits;

img_data.ScreenBoundBox=bsxfun(@minus,fixed_points(1:4,:),[xdata(1),ydata(1)])';
img_data.leftbottom=img_data.ScreenBoundBox(:,4);

figure;
imshow(img_pro,[]); hold on;
plot(img_data.ScreenBoundBox(1,[1:4,1]),img_data.ScreenBoundBox(2,[1:4,1]),'LineWidth',2,'color','r');

img_data.img=img_pro;
img_data.ScreenWidth=width;
img_data.ScreenHeight=height;
img_data.long_vec_norm=[1,0];
img_data.short_vec_norm=[0,-1];
img_data.tform=tform;




function lines4=FindBoxEdges(lines)
start_idx=1;
lines2=lines;
num=1;

while(1)
    theta_group=[lines2.theta];
    same_theta_idx=find(abs(theta_group-lines2(start_idx).theta)<30|abs(abs(theta_group-lines2(start_idx).theta)-180)<30);
    same_line_idx=false(1,length(same_theta_idx));
    
    vec_start=lines2(start_idx).point2-lines2(start_idx).point1;
    vec_start=vec_start/norm(vec_start)*10;
    vector=[];
    
    for i=1:length(same_theta_idx)
        
        if same_theta_idx(i)==start_idx
            same_line_idx(i)=true;
        end
        
        vec=lines2(start_idx).point2-lines2(same_theta_idx(i)).point1;
        
        if norm(vec)<1e-2
            same_line_idx(i)=true;
        else
        
        vec=vec/norm(vec)*10;
        
        if (norm(vec-vec_start)<3|| norm(vec+vec_start)<3)
            same_line_idx(i)=true;
        else
            same_line_idx(i)=false;
        end
        end
            
    end
    
    
    lines_temp=lines2(same_theta_idx(same_line_idx));
    
    for i=1:length(lines_temp)
        vector(i,:)=lines_temp(i).point2-lines_temp(i).point1;
        vector(i,:)=vector(i,:)/norm(vector(i,:));
    end
    
    
    
    vec_new=mean(vector,1)*50;
    
    
    lines4(num).point1=lines_temp(1).point1;
    lines4(num).point2=lines_temp(1).point1+vec_new;
    lines4(num).theta=lines_temp(1).theta;
    
    num=num+1;
    
    lines2(same_theta_idx(same_line_idx))=[];
    
    if isempty(lines2)
        break;
    end
end



function corners=FindCorners(lines)
    
start_idx=1;
theta_group=[lines.theta];
group1_idx=find(abs(theta_group-lines(start_idx).theta)<50|abs(abs(theta_group-lines(start_idx).theta)-180)<50);

group1_lines=lines(group1_idx);
lines(group1_idx)=[];
group2_lines=lines;

if (length(group1_lines)~=2|length(group2_lines)~=2)
    error('2 lines');
end

corners=[];
for i=1:2
    for j=1:2
    
 A=[(group1_lines(i).point2-group1_lines(i).point1)',...
     -(group2_lines(j).point2-group2_lines(j).point1)'];
 
 
 B=(group2_lines(j).point1-group1_lines(i).point1)';
 
 K=A\B;
 
 P=K(1)*(group1_lines(i).point2-group1_lines(i).point1)+group1_lines(i).point1;
 corners=[corners,P'];
    end
end

[a,idx]=sort(corners(1,:),'ascend');
[b,idy1]=sort(corners(2,idx(1:2)),'ascend');
[b,idy2]=sort(corners(2,idx(3:4)),'ascend');
temp=idx(3:4);
idx=[idx(idy1(1)),temp(idy2(1)),temp(idy2(2)),idx(idy1(2))];
corners=corners(:,idx);