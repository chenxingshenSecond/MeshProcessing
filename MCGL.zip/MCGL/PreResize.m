function [im_resize,shift]= PreResize(ori_img , filter_min , factor , method )
%%
if (isempty(method)|method(1)~='b')
    if numel(size(ori_img))>2
        img_gray=double(rgb2gray(ori_img));
        img_gray=img_gray/max(max(img_gray));
    else
        img_gray=ori_img;
    end
else
    img_gray=double(ori_img(:,:,3));
    img_gray=img_gray/max(max(img_gray));
end

im_bw=im2bw(img_gray,graythresh(img_gray));
im_bw=imclose(im_bw,strel('disk',floor(filter_min/3)));
CC=bwconncomp(im_bw);
numPixels=cellfun(@numel,CC.PixelIdxList);
[biggest,idx]=max(numPixels);
im_bw=zeros(size(im_bw));
im_bw(CC.PixelIdxList{idx})=1;

[i,j]=find(im_bw);
[m,n]=size(im_bw);
height_min=min(i)-40;
height_max=max(i)+40;
width_min=min(j)-40;
width_max=max(j)+40;
%%
h_add_top=abs(min(0,height_min));
h_add_bottom=abs(min(0,m-height_max));
w_add_left=abs(min(0,width_min));
w_add_right=abs(min(0,n-width_max));
%%
m_expand=m+h_add_top+h_add_bottom;
n_expand=n+w_add_left+w_add_right;
%%
h1=h_add_top+1;
h2=h_add_top+m;
w1=w_add_left+1;
w2=w_add_left+n;

h11=max(1,height_min);
h22=abs(min(height_min,0))+height_max;
w11=max(1,width_min);
w22=abs(min(width_min,0))+width_max;

if numel(size(ori_img))<3
    im_expand=zeros(m_expand,n_expand);
    im_expand(h1:h2,w1:w2)=ori_img;
    im_crop=im_expand(h11:h22,w11:w22);
else
    im_expand=uint8(zeros(m_expand,n_expand,3));
    im_expand(h1:h2,w1:w2,:)=ori_img;
    im_crop=im_expand(h11:h22,w11:w22,:);
end
%% 
im_resize=imresize(im_crop,factor);
shift.x=min(width_min,0)+max(width_min-1,0);
shift.y=min(height_min,0)+max(height_min-1,0);
shift.factor=factor;
shift.expand=[m_expand n_expand];
shift.copy=[h1,h2;w1,w2];
shift.crop=[h11,h22;w11,w22];