
function im_resize = PreResize2(ori_img,shift)
m_expand=shift.expand(1); 
n_expand=shift.expand(2);

h1=shift.copy(1,1);
h2=shift.copy(1,2);
w1=shift.copy(2,1);
w2=shift.copy(2,2);

h11=shift.crop(1,1);
h22=shift.crop(1,2);
w11=shift.crop(2,1);
w22=shift.crop(2,2);

im_expand=uint8(zeros(m_expand,n_expand,3));
im_expand(h1:h2,w1:w2,:)=ori_img;
im_crop=im_expand(h11:h22,w11:w22,:);
im_resize = imresize( im_crop,shift.factor); %%
