function retval = vertex_colors_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.VC);
