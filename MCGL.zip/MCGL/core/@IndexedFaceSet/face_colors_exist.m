function retval = face_colors_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.FC);
