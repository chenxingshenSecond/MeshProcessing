function retval = face_normals_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.FN);
