function retval = key_frames_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.A);
