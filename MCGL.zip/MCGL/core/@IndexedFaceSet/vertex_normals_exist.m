function retval = vertex_normals_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.VN);
