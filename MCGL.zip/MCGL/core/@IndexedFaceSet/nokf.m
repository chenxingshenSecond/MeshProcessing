function retval = nokf(IFSObj,varargin)

retval = length(IFSObj.A);
