function retval = nof(IFSObj,varargin)

retval = double(IFSObj.nf);
