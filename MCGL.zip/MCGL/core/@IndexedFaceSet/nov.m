function retval = nov(IFSObj,varargin)

retval = double(IFSObj.nv);
