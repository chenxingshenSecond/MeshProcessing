function retval = novc(IFSObj,varargin)

retval = size(IFSObj.FC,1);
