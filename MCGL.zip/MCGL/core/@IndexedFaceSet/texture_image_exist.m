function retval = texture_image_exist(IFSObj,varargin)

retval = ~isempty(IFSObj.TImg);
