function retval = nob(HEObj,varargin)

retval = double(HEObj.nb);
