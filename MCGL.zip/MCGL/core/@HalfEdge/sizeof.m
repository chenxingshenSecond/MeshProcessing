function retval = sizeof(HEObj)

retval = 0;
error('Sizeof is not supported yet.');

