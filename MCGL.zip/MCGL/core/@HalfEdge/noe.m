function retval = noe(HEObj,varargin)

retval = double(HEObj.ne);
