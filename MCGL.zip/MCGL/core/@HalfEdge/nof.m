function retval = nof(HEObj,varargin)

retval = nof(HEObj.indexedfaceset)+nob(HEObj);
