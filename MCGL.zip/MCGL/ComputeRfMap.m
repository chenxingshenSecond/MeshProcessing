function map =ComputeRfMap ( Centroid_toScreen , shift , img_data , radius , list , MultiCamParam , camNum , varargin    ) %
lens_center =  ComputeImageLensCenter(Centroid_toScreen,img_data);
map         =  zeros(13,13,size(Centroid_toScreen,1 ) );  %% 
%% 
[off_set_x,off_set_y]=meshgrid(  -6: 1 : 6  ,   - 6 : 1 : 6 ) ;
off_set_xy  = [ off_set_x(:) , off_set_y(:) ] ;

tform_pro = projective2d ( img_data.tform.tdata.T );
num_pic   = length(list) ; 
%%  
A=cellfun(@(x) regexp(x,'\d*','match'),{list.name},'UniformOutput',false )';
B=zeros(length(A),1);

for i=1:length(A)
   B(i)=str2num(cell2mat(A{i}(3))); 
end

[BB,idx] = sort(B,'ascend');
list     = list(idx) ;
if nargin >= 8 
    If_rotate_flag  = varargin{1} ;
end
if nargin >= 9 
    lens_center  = varargin{2} ; 
    disp('lenes center ') ; 
end

for i=1:num_pic
    if If_rotate_flag > 0.5   
        im_read      =  imrotate ( imread(strcat('',list(i).name)) , 180 ); 
    else
        im_read      =   imread(strcat('',list(i).name)) ;
    end
    im_undistort = Undistort_Images( im_read , MultiCamParam , camNum ); %% 
    im_crop      = PreResize2 ( im_undistort , shift ); %% 
    
    im_gray=double(rgb2gray(im_crop)); 
    
    
    im_trans=imwarp( im_gray , tform_pro,'cubic'); 
    
    figure ; imshow( im_trans , [] ) ; hold on ;  plot( lens_center(:,1) , lens_center(:,2) ,  '*' ) ;

     m = 7-off_set_xy(i,2);
     n = 7+off_set_xy(i,1);
    for j=1:size(lens_center,1)
         im_pack=im_trans(round(lens_center(j,2)-radius):round(lens_center(j,2)+radius),round(lens_center(j,1)-radius):round(lens_center(j,1)+radius));
         map(m,n,j)=sum(sum(im_pack))/numel(im_pack);
    end
end

function lens_center=ComputeImageLensCenter(Centroid_toScreen,img_data)
lens_center=repmat(Centroid_toScreen(:,1),1,2).*repmat(img_data.long_vec_norm,size(Centroid_toScreen,1),1)...
    +repmat(Centroid_toScreen(:,2),1,2).*repmat(img_data.short_vec_norm,size(Centroid_toScreen,1),1)...
    +repmat(img_data.leftbottom',size(Centroid_toScreen,1),1);


function im_resize = PreResize2(ori_img,shift)
m_expand=shift.expand(1);
n_expand=shift.expand(2);

h1=shift.copy(1,1);
h2=shift.copy(1,2);
w1=shift.copy(2,1);
w2=shift.copy(2,2);

h11=shift.crop(1,1);
h22=shift.crop(1,2);
w11=shift.crop(2,1);
w22=shift.crop(2,2);

im_expand=uint8(zeros(m_expand,n_expand,3));
im_expand(h1:h2,w1:w2,:)=ori_img;
im_crop=im_expand(h11:h22,w11:w22,:);
im_resize = imresize( im_crop,shift.factor); %%

